﻿using Microsoft.EntityFrameworkCore;
using HesapMakinesiApi.Models; 

namespace HesapMakinesiApi.Data 
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {
        }

        public DbSet<IslemGecmisi> IslemGecmisi { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<IslemGecmisi>().ToTable("IslemGecmisi");
        }
    }
}