﻿using HesapMakinesiApi.Data;
using HesapMakinesiApi.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace HesapMakinesiApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class HesaplamaController : ControllerBase
    {
        private readonly AppDbContext _context;

        public HesaplamaController(AppDbContext context)
        {
            _context = context;
        }

        [HttpPost("hesapla")]
        public async Task<IActionResult> Hesapla([FromBody] HesaplamaRequest request)
        {
            double sonuc = 0;

            if (request == null)
            {
                return BadRequest(new { basarili = false, mesaj = "Geçersiz istek verisi." });
            }

            try
            {
                switch (request.Islem)
                {
                    case "+": sonuc = request.Sayi1 + request.Sayi2; break;
                    case "-": sonuc = request.Sayi1 - request.Sayi2; break;
                    case "*": sonuc = request.Sayi1 * request.Sayi2; break;
                    case "/":
                        if (request.Sayi2 == 0)
                            return Ok(new { basarili = false, mesaj = "Sıfıra bölme hatası!" });
                        sonuc = request.Sayi1 / request.Sayi2;
                        break;
                    default:
                        return BadRequest(new { basarili = false, mesaj = "Geçersiz işlem!" });
                }

                var kayit = new IslemGecmisi
                {
                    Sayi1 = request.Sayi1,
                    Sayi2 = request.Sayi2,
                    Islem = request.Islem,
                    Sonuc = sonuc,
                    Tarih = DateTime.Now
                };

                _context.IslemGecmisi.Add(kayit);
                await _context.SaveChangesAsync();

                return Ok(new { basarili = true, sonuc = sonuc });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { basarili = false, mesaj = "Hata: " + ex.Message });
            }
        }

      

        [HttpGet("gecmis")]
        public async Task<IActionResult> Gecmis()
        {
            try
            {
                var gecmis = await _context.IslemGecmisi
                    .OrderByDescending(h => h.Tarih)
                    .Take(10)
                    .ToListAsync();

                return Ok(gecmis);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { basarili = false, mesaj = "Geçmiş yüklenirken hata: " + ex.Message });
            }
        }

        [HttpPost("gecmis-temizle")]
        public async Task<IActionResult> GecmisTemizle()
        {
            try
            {
                _context.IslemGecmisi.RemoveRange(await _context.IslemGecmisi.ToListAsync());
                await _context.SaveChangesAsync();
                return Ok(new { basarili = true });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { basarili = false, mesaj = "Geçmiş temizlenirken hata: " + ex.Message });
            }
        }
    }
}